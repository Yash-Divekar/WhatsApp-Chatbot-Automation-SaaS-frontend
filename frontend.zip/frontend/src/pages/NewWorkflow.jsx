import React from 'react'

function NewWorkflow() {
  return (
    <div>NewWorkflow</div>
  )
}

export default NewWorkflow