import React from 'react'

function Stimulate() {
  return (
    <div>Stimulate</div>
  )
}

export default Stimulate