import React from 'react'

function Workflows() {
  return (
    <div>Workflows</div>
  )
}

export default Workflows